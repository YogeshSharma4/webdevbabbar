package com.example.UserService.exception;

public class UserNotFoundException extends RuntimeException{

    public UserNotFoundException(){
        super("UserNotFoundException");
    }

    public UserNotFoundException(String msg){
        super(msg);
    }
}
