package com.example.UserService.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "UserTable")
public class User {

    @Id
    private String userId;
    @NotBlank
    private String name;
    @NotBlank
    private String email;
    private String about;

    @Transient
    private List<Rating> ratings = new ArrayList<>();
}
