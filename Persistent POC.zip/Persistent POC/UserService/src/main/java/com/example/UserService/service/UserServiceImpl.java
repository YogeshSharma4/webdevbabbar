package com.example.UserService.service;

import com.example.UserService.entity.Hotel;
import com.example.UserService.entity.Rating;
import com.example.UserService.entity.User;
import com.example.UserService.exception.UserNotFoundException;
import com.example.UserService.external.service.HotelService;
import com.example.UserService.external.service.RatingService;
import com.example.UserService.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    UserRepository userRepository;

    @Autowired
    RatingService ratingService;

    @Autowired
    HotelService hotelService;

    @Override
    public User saveUser(User user) {
        String userId = UUID.randomUUID().toString();
        user.setUserId(userId);
        return userRepository.save(user);
    }

    @Override
    public List<User> getAllUser() {
        return userRepository.findAll();
    }

    @Override
    public User getUser(String userId) {
        User user = userRepository.findById(userId).orElseThrow(() -> new UserNotFoundException("User with given id is not found Exception "+userId));;

        List<Rating> ratingList = ratingService.getRatingByUserId(userId);
        List<Rating> ratingListWithHotel = ratingList.stream().map(rating -> {
            Hotel hotel = hotelService.getHotel(rating.getHotelId());
            rating.setHotel(hotel);
            return rating;
        }).toList();
        user.setRatings(ratingListWithHotel);
        return user;

    }

    @Override
    public void deleteUser(User user) {
        userRepository.delete(user);
    }
}
